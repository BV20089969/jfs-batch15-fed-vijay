import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  template: ''
})
export class BasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}