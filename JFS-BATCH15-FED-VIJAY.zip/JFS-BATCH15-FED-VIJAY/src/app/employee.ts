export class Employee {
    id: number;
    name:string;
    location: string;
    email: string;
    mobile: number;
 }